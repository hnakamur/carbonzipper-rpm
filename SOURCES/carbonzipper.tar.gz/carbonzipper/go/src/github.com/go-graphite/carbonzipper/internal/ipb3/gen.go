package ipb3

//go:generate protoc --gogofast_out=. ipb3.proto
