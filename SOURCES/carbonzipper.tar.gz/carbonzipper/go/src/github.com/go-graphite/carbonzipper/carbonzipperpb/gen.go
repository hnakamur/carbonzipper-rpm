package carbonzipperpb

//go:generate protoc --gogofast_out=. carbonzipper.proto
