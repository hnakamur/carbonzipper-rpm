package carbonzipperpb

//go:generate protoc --gogofast_out=. carbonzipper.proto --proto_path=../vendor/ --proto_path=.
