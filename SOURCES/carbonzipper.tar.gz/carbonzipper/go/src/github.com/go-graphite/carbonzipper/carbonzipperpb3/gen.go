package carbonzipperpb3

//go:generate protoc --gogofast_out=. carbonzipper3.proto --proto_path=../vendor/ --proto_path=.
