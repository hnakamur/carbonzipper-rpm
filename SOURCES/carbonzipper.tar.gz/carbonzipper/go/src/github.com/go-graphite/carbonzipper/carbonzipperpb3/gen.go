package carbonzipperpb3

//go:generate protoc --gogofast_out=. carbonzipper3.proto
